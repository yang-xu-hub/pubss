#include "dictionary.h"
int myerror;
int flags;
int register_num=0;//记录已注册的用户个数
char *errmsg=NULL;
char client_now[20];
int8_t word_dr[BUFSIZ];
void my_perror(){
	switch(myerror){
		case DIC_LOGIN_SUCCEED:
			printf("登录成功\n");
			break;
		case DIC_LOGIN_ING:
			printf("正在登录\n");
			break;
		case DIC_LOGIN_FAILED:
			printf("登录失败\n");
			break;
		case DIC_LOGIN_NO:
			printf("未登录\n");
			break;
		case DIC_REGISTER_SUCCEED:
			printf("注册成功\n");
			break;
		case DIC_REGISTER_ING:
			printf("正在注册\n");
			break;
		case DIC_REGISTER_FAILED:
			printf("注册失败\n");
			break;
		case DIC_REGISTER_NO:
			printf("未注册\n");
			break;
		case DIC_WORD_FAND:
			printf("找到单次信息\n");
			break;
		case DIC_WORD_ING:
			printf("正在查询单词\n");
			break;
		case DIC_WORD_NOFAND:
			printf("未找到单词\n");
			break;
		case DIC_HISTORY_HAVE:
			printf("找到历史\n");
			break;
		case DIC_HISTORY_ING:
			printf("正在查询历史\n");
			break;
		case DIC_HISTORY_NULL:
			printf("无历史\n");
			break;
		case DIC_SERVER_CLOSE:
			printf("服务器已关闭\n");
			break;
		case DIC_BUF_FULL:
			printf("缓存已满\n");
			break;
		case DIC_ERROR:
			printf("未知错误\n");
			break;
		case DIC_UPDATESUCCEED:
			printf("更新成功\n");
			break;
		case DIC_UPDATEFAILED:
			printf("更新失败\n");
			break;
		default:
			printf("目前为止加载成功\n");
			break;
	}
}
void cli_info(struct sockaddr_in cin,int fd){
	char ip4_addr[16];
	if(NULL==inet_ntop(AF_INET,&cin.sin_addr.s_addr,ip4_addr,sizeof(ip4_addr))){
		perror("inet_pton");
		return;
	}
	printf("文件描述符:%d--客户端(%s:%d)已连接\n",fd,ip4_addr,ntohs(cin.sin_port));
}
int funmax(int maxfd,fd_set readfd){
	int i;
	for(i=maxfd+1;i>0;i--){
		if(FD_ISSET(i,&readfd)){
			return i;
		}
	}
	return -1;
}
//void recv_start(int fd){
//	return;
//}
int recv_info_send(int fd,int *maxfd,fd_set *readfd,sqlite3 *db){
	cs com;//定义一个通过结构体变量来接受服务器的消息
	int tt_flag;
	int recv_t=-1;
	char nofind[10]="nofind";
	do{
		recv_t=recv(fd,&com,sizeof(com),0);
	}while(recv_t<0&&EINTR==errno);//因为
	//内核将其进入睡眠状态时中断接收导致的失败，
	//误将其归为下方的其他中断接收导致的失败
	//从而让其再次循环接收消息
	if(recv_t<0){
		perror("recv");
		return -1;
	}else if(0==recv_t){
		printf("对方%d已经关闭链接\n",fd);
		FD_CLR(fd,readfd);
		close(fd);
		//当关闭某个链接时，需要重新确定maxfd值
		*maxfd=funmax(*maxfd,*readfd);
		return 0;
	}else{
		tt_flag=info_func(&com,db,fd);
		switch(tt_flag){
			case DIC_LOGIN_SUCCEED:
				bzero(client_now,20);//先清空上一次登录的客户
				strcpy(client_now,(char*)(((lr*)&com)->name));//更新客户
				send_info_lr(fd,DIC_LOGIN_SUCCEED);
				break;
			case DIC_LOGIN_FAILED:
				send_info_lr(fd,DIC_LOGIN_FAILED);
				break;
			case DIC_REGISTER_SUCCEED:
				send_info_lr(fd,DIC_REGISTER_SUCCEED);
				break;
			case DIC_REGISTER_FAILED:
				send_info_lr(fd,DIC_REGISTER_FAILED);
				break;
			case DIC_WORD_FAND:
				myerror=history_update(db,&com);//查找到则更新历史记录
				my_perror();
				send_info_word(fd,word_dr,strlen((char*)word_dr));
				break;
			case DIC_WORD_NOFAND:
				send_info_word(fd,(int8_t*)nofind,7);
				break;
			case DIC_HISTORY_HAVE:
				printf("查询到某些历史\n");
				break;
			case DIC_HISTORY_NULL:
				printf("无历史\n");
				break;
			case DIC_UPDATESUCCEED:
				printf("更新成功\n");
				break;
			case DIC_ERROR1:
				printf("错误1\n");
				break;
			case DIC_ERROR2:
				printf("错误2\n");
				break;
			case DIC_ERROR3:
				printf("错误3\n");
				break;
			case DIC_ERROR4:
				printf("错误4\n");
				break;
			default:
				myerror=DIC_ERROR;
				break;
		}
	}
	return 1;
}
int info_func(cs* buf,sqlite3 *db,int fd){
	//判断客户机是登录，注册还是查词
	if(buf->head==DIC_LOGIN_ING){
		//登录则处理登录信息并返回是否成功登录
		return start_login((lr*)buf,db);
	}else if(buf->head==DIC_REGISTER_ING){
		//注册则处理注册信息并返回是否成功注册
		return start_register((lr*)buf,db);
	}else if(buf->head==DIC_WORD_ING){
		//查词则返回找到词的信息
		return word_info((word*)buf);
	}else if(buf->head==DIC_HISTORY_ING){
		return history_info((hc*)buf,db,fd);
	}else{
		printf("无任何head\n");
	}
	return -1;
}
void send_info_lr(int fd,int8_t sp){
	//发送枚举值给客户机，客户机以此来判断是成功还是失败
	int ret=-1;
	do{
		ret=send(fd,&sp,1,0);
	}while(ret<0&&EINTR==errno);
	if(ret<0&&EPIPE==errno){
		perror("set");
		printf("对方关闭了链接\n");
		return;
	}
	if(0==ret){
		printf("发送过多导致缓冲区已满\n");
		return;
	}
	printf("发送成功\n");
}
int start_login(lr *buf,sqlite3 *db){
	//对登录信息进行处理以此来判断登录是否成功的函数
	char order1[100];//这里数量不能设置少，否则导致函数状态被覆盖
	int num_select=0;//用这个数字判断是否查询到
	sprintf(order1,"select name from accounts where name=\"%s\" and passwd=\"%s\"",(char*)buf->name,(char*)buf->passwd);
	if(sqlite3_exec(db,order1,callback_register,&num_select,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"select:%s\n",sqlite3_errmsg(db));
		fprintf(stderr,"select:%s\n",errmsg);
		return DIC_LOGIN_FAILED;
	}
	if(num_select==1){
		return DIC_LOGIN_SUCCEED;
	}
	return DIC_LOGIN_FAILED;
}
int callback_register(void* para,int f_num,char **f_value,char **f_name){
	(*(int*)para)++;
	return 0;
}
int start_register(lr *buf,sqlite3 *db){
	//对注册信息进行处理以此来判断注册是否成功的函数
	//并根据成功与否，来决定是否写入表中
	//1.首先查找是否有相同的用户名，有便返回失败
	char order1[50];
	int num_select=0;
	sprintf(order1,"select name from accounts where name=\"%s\"",(char*)buf->name);
	if(sqlite3_exec(db,order1,callback_register,&num_select,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"select:%s\n",sqlite3_errmsg(db));
		fprintf(stderr,"select:%s\n",errmsg);
		return DIC_REGISTER_FAILED;
	}
	printf("-------22222\n");
	printf("num_select:%d\n",num_select);
	if(num_select==0){//说明没有相同注册名，开始添加成员
		printf("-------1111\n");
		char order2[50];
		sprintf(order2,"insert into accounts values (%d,\"%s\",\"%s\")",register_num,(char*)buf->name,(char*)buf->passwd);
		if(sqlite3_exec(db,order2,NULL,NULL,&errmsg)!=SQLITE_OK){
			fprintf(stderr,"select:%s\n",sqlite3_errmsg(db));
			fprintf(stderr,"select:%s\n",errmsg);
			return DIC_REGISTER_FAILED;
		}
		register_num++;
		return DIC_REGISTER_SUCCEED;
	}
	return DIC_REGISTER_FAILED;
}
void send_info_word(int fd,int8_t *sp,int len){
	//发送查询到的解释给客户机
	int ret=-1;
	do{
		ret=send(fd,sp,len,0);
		printf("%d\n",ret);
	}while(ret<0&&EINTR==errno);
	if(ret<0&&EPIPE==errno){ 
		perror("set");
		printf("对方关闭了链接\n");
		return;
	}
	if(0==ret){
		printf("发送过多导致缓冲区已满\n");
		return;
	}
	printf("发送成功\n");
}
int word_info(word *buf){
	bzero(word_dr,BUFSIZ);//将上一次查找的解析值清空
	char kep[20];
	char temp[BUFSIZ];
	strcpy(kep,(char*)buf->word);
	FILE *fd=fopen("dict.txt","r");//创建一个流指针
	while(fgets(temp,BUFSIZ,fd)){
		if(strncmp(kep,temp,strlen(kep))==0&&temp[strlen(kep)]==' '){
			strcpy((char*)word_dr,temp);
			fclose(fd);
			return DIC_WORD_FAND;
		}
	}
	fclose(fd);
	return DIC_WORD_NOFAND;
}
int callback_history(void *para,int f_num,char **f_value,char **f_name){
	his *temp=(his*)para;
	if(temp->num>6){
		return 1;//超出6就不继续调用该函数
	}
	strcpy((char*)(temp->words[temp->num]).word,f_value[1]);//根据num值将word填入
	strcpy((char*)(temp->words[temp->num]).time,f_value[2]);//根据num值将time填入
	printf("word:%s\n",(char*)(temp->words[temp->num]).word);//观察是否写入
	printf("time:%s\n",(char*)(temp->words[temp->num]).time);//观察是否写入
	temp->num++;
	return 0;
}
int history_info(hc *buf,sqlite3 *db,int fd){
	//将该客户端的历史记录，从该函数直接发出
	char order1[100];
	his historys;
	sprintf(order1,"select * from historys where name=\"%s\"",(char*)buf->client);
	if(sqlite3_exec(db,order1,callback_history,&historys,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"select:%s\n",sqlite3_errmsg(db));
		fprintf(stderr,"select:%s\n",errmsg);
		return DIC_ERROR;
	}
	send_info_history(fd,&historys,sizeof(his));
	if(historys.num==0)
		return DIC_HISTORY_NULL;
	else
		return DIC_HISTORY_HAVE;
	
}
void send_info_history(int fd,his *my_his,int len){
	int ret=-1;
	do{
		ret=send(fd,my_his,len,0);
		printf("%d\n",ret);
	}while(ret<0&&EINTR==errno);
	if(ret<0&&EPIPE==errno){ 
		perror("set");
		printf("对方关闭了链接\n");
		return;
	}
	if(0==ret){
		printf("发送过多导致缓冲区已满\n");
		return;
	}
	printf("发送成功\n");
}
int history_update(sqlite3 *db,cs* my_com){
	word *temp=(word*)my_com;
	//先查找该信息是否已存在
	char order1[100];
	//char order2[100];
	int num_select=0;
	time_t time_kk;
	time_kk=time(NULL);
	sprintf(order1,"select * from historys where name=\"%s\" and word=\"%s\"",client_now,(char*)temp->word);
	if(sqlite3_exec(db,order1,callback_register,&num_select,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"select:%s\n",sqlite3_errmsg(db));
		fprintf(stderr,"select:%s\n",errmsg);
		return DIC_ERROR4;
	}
	if(num_select==1){
		printf("22222\n");
		bzero(order1,100);
		sprintf(order1,"update historys set time=%ld where name=\"%s\" and word=\"%s\"",time_kk,client_now,(char*)temp->word);
		if(sqlite3_exec(db,order1,NULL,NULL,&errmsg)!=SQLITE_OK){
			fprintf(stderr,"update:%s\n",sqlite3_errmsg(db));
			fprintf(stderr,"update:%s\n",errmsg);
			return DIC_ERROR3;
		}
	}
	if(num_select==0){
		printf("11111\n");
		bzero(order1,100);
		sprintf(order1,"insert into historys values(\"%s\",\"%s\",%ld)",client_now,(char*)temp->word,time_kk);
		if(sqlite3_exec(db,order1,NULL,NULL,&errmsg)!=SQLITE_OK){
			fprintf(stderr,"insert:%s\n",sqlite3_errmsg(db));
			fprintf(stderr,"insert:%s\n",errmsg);
			return DIC_ERROR2;
		}
	}
	if(num_select>1){
		printf("num_select:%d\n",num_select);
		return DIC_ERROR1;
	}

	return DIC_UPDATESUCCEED;
}
