#include "dictionary.h"
extern int myerrno;
extern int flags;
extern int register_num;
extern char *errmsg;
extern char client_now[20];
int main(int argc,const char *argv[]){
	sqlite3 *db=NULL;
	if(sqlite3_open("clients.db",&db)!=SQLITE_OK){
		//errmsg=sqlite3_errmsg(db);
		fprintf(stderr,"%s\n",sqlite3_errmsg(db));
		exit(1);
	}
	printf("打开数据库成功\n");
	if(sqlite3_exec(db,"create table accounts(id int,name string,passwd string)",NULL,NULL,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"create:%s\n",sqlite3_errmsg(db));
	}
	printf("创建数据账户表成功\n");
	if(sqlite3_exec(db,"create table historys(name string,word string,time int)",NULL,NULL,&errmsg)!=SQLITE_OK){
		fprintf(stderr,"create:%s\n",sqlite3_errmsg(db));
	}
	printf("创建数据历史表成功\n");
	int fd=-1;
	//建立套接字
	fd=socket(AF_INET,SOCK_STREAM,0);
	if(fd<0){
		perror("socket");
		return -1;
	}
	printf("socket success\n");
	//设置地址快速重用
	int flag=1;
	int res_set=setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&flag,sizeof(flag));
	if(res_set<0){
		perror("setsockopt");
		return -1;
	}
	printf("setsockopt success\n");
	//将
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SERV_PORT);
	int res_pton=inet_pton(AF_INET,"0.0.0.0",&sin.sin_addr.s_addr);
	if(res_pton<0){
		perror("inet_pton");
		return -1;
	}
	printf("inet_pton success\n");
	//将地址与端口与套接字绑定
	int res_bind=bind(fd,(struct sockaddr*)&sin,sizeof(sin));
	if(res_bind<0){
	perror("bind");
		return -1;
	}
	printf("bind success\n");
	//监听
	int res_listen=listen(fd,BACKLOG);
	if(res_listen<0){
		perror("listen");
		return -1;
	}
	printf("listen success\n");
	struct sockaddr_in cin;
	socklen_t addrlen=sizeof(cin);
	fd_set readfd,temp;
	//FD_SET(0,&readfd);
	FD_SET(fd,&readfd);
	int maxfd=fd;
	//char buf[128]={};
	int val=-1;
	//int recv_t=-1;
	//int setfd=-1;
	int i=-1;
	int newfd=-1;
	//char p_addr[16];
	int st_flag;
	//创建一个客户账户库
	while(1){
		temp=readfd;
		val=select(maxfd+1,&temp,NULL,NULL,NULL);
		if(val<0){
			perror("select");
			return -1;
		}
		for(i=1;i<maxfd+1;i++){
			if(FD_ISSET(i,&temp)){
				if(i==fd){
					printf("2222\n");
					newfd=accept(fd,(struct sockaddr*)&cin,&addrlen);
					if(newfd<0){
						perror("accept");
						break;
					}
					printf("1111\n");
					cli_info(cin,newfd);//打印信息
					FD_SET(newfd,&readfd);//将新建立的链接加入监听集合中
					maxfd=(maxfd>newfd)?maxfd:newfd;//更新最大maxfd
				}else{
					//接受消息，并发送yes或no或查词的信息
					st_flag=recv_info_send(i,&maxfd,&readfd,db);
					if(st_flag==0){
						printf("客户端关闭\n");
						continue;
					}else if(st_flag==1){
						printf("主机发送成功\n");
						continue;
					}else if(st_flag==-1){
						printf("出现未知错误\n");
						continue;
					}
				}
			}
		}
	};
	sqlite3_close(db);
	close(fd);
	return -1;
}
