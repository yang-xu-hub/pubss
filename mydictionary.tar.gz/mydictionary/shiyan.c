#include <stdio.h>
int main(int argc, const char *argv[])
{
	char *p="hello";
	char *q=p;
	printf("%s\n",q);
	return 0;
}
