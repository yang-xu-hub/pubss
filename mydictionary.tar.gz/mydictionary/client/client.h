#ifndef CLIENT_H__
#define CLIENT_H__ 
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <time.h>
//#include <signal.h>
//#include <sys/wait.h>
//#include <sys/stat.h>
//#include <fcntl.h>
struct common_struct{//该结构体是包含有head属性的通用结构体便于客户机转换
	int8_t head;//主机根据这个来判断是哪个结构体
	int8_t tongyong[40];//head的最大为40
}__attribute__((packed));
struct info_lr{//登录注册结构体
	int8_t head;
	int8_t name[20];
	int8_t passwd[20];
}__attribute__((packed));
struct info_word{//查词结构体
	int8_t head;
	int8_t word[20];
}__attribute__((packed));
struct history_words{//历史单词单个结构体
	int8_t word[20];
	int8_t time[20];
}__attribute__((packed));
struct info_history{//主机返回的历史记录结构体
	int8_t num;//最大为6
	struct history_words words[6];
}__attribute__((packed));
struct history_client{//发送客户历史结构体
	int8_t head;
	int8_t client[20];
}__attribute__((packed));
typedef struct info_lr lr;
typedef struct info_word word;
typedef struct history_words hw;
typedef struct info_history his;
typedef struct history_client hc;
#define BUF_SIZE 5
#define SERV_PORT 6666
#define SERV_IP_ADDR "192.168.2.154"
#define BACKLOG 10
#define QUIT "quit"
enum DIC{
	DIC_LOGIN_SUCCEED=0,
	DIC_LOGIN_ING,
	DIC_LOGIN_FAILED,
	DIC_LOGIN_NO,

	DIC_REGISTER_SUCCEED,
	DIC_REGISTER_ING,
	DIC_REGISTER_FAILED,
	DIC_REGISTER_NO,
	
	DIC_WORD_FAND,
	DIC_WORD_ING,
	DIC_WORD_NOFAND,

	DIC_HISTORY_HAVE,
	DIC_HISTORY_ING,
	DIC_HISTORY_NULL,

	DIC_SERVER_CLOSE,
	DIC_BUF_FULL,
	DIC_ERROR,
};
void myperror();
int login_start(int);
int register_start(int);
int input_info_lr(int,lr*);
void send_account_ms(int,const void*,void*,int);
void search_start(int);
void search_history(int);

//void send_info_recv(int,const char*,char*);
#endif
