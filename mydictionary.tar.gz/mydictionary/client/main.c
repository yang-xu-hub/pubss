#include "client.h"
extern int myflag;
extern char client_name[10];
//myflag=DIC_NO_LOGIN;
int main(int argc, const char *argv[])
{
	//建立套接字
	//myflag=DIC_NO_LOGIN;
	int fd=-1;
	fd=socket(AF_INET,SOCK_STREAM,0);
	if(fd<0){
		perror("socket");
		return -1;
	}
	printf("socket success\n");
	//设置地址快速重用
	int flag=1;
	int res_set=setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&flag,sizeof(flag));
	if(res_set<0){
		perror("setsockopt");
		return -1;
	}
	printf("setsockopt sucess\n");
	//填充地址等信息
	struct sockaddr_in sin;
	sin.sin_family=AF_INET;
	sin.sin_port=htons(SERV_PORT);
	int res_pton=inet_pton(AF_INET,SERV_IP_ADDR,&sin.sin_addr.s_addr);
	if(res_pton<0){
		perror("inet_pton");
		return -1;
	}
	printf("sin success\n");
	//连接
	int res_connect=connect(fd,(struct sockaddr*)&sin,sizeof(sin));
	if(res_connect<0){
		perror("connect");
		return -1;
	}
	printf("connect success\n");
	//注册或者登录
	int a;
	int flag1=1;
	char buf[BUFSIZ]="";
	while(flag1){
		bzero(buf,BUFSIZ);
		printf("请选择你的操作：1-登录，2-注册，3-查词，4-历史记录，5-退出登录，6退出:");
		scanf("%d",&a);
		while(getchar()!='\n');
		switch(a){
			case 1:
				if(DIC_LOGIN_SUCCEED==myflag){
					printf("您已登录，请先退出登录\n");
					break;
				}
				myflag=login_start(fd);
				break;
			case 2:
				if(DIC_LOGIN_SUCCEED==myflag){
					printf("您已登录，请先退出登录\n");
					break;
				}
				myflag=register_start(fd);
				break;
			case 3:
				if(DIC_LOGIN_SUCCEED!=myflag){
					printf("请先注册或登录\n");
					break;
				}
				search_start(fd);
				break;
			case 4:
				if(DIC_LOGIN_SUCCEED!=myflag){
					printf("请先注册或登录\n");
					break;
				}
				search_history(fd);
				break;
			case 5:
				if(myflag!=DIC_LOGIN_SUCCEED){
					printf("您并未登录，请登录或注册\n");
					break;
				}
				myflag=DIC_LOGIN_NO;
				printf("您已经退出登录\n");
				break;
			case 6:flag1=0;break;
			default:printf("请重新输入\n");continue;break;
		}
	}
	printf("exit\n");
	close(fd);
	return 0;
}

