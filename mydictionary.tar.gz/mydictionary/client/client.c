#include "client.h"
int myflag=DIC_LOGIN_NO;
char client_name[20]="";
void myperror(){
	switch(myflag){
		case DIC_LOGIN_SUCCEED:
			printf("登录成功\n");
			break;
		case DIC_LOGIN_ING:
			printf("正在登录\n");
			break;
		case DIC_LOGIN_FAILED:
			printf("登录失败\n");
			break;
		case DIC_LOGIN_NO:
			printf("未登录\n");
			break;
		case DIC_REGISTER_SUCCEED:
			printf("注册成功\n");
			break;
		case DIC_REGISTER_ING:
			printf("正在注册\n");
			break;
		case DIC_REGISTER_FAILED:
			printf("注册失败\n");
			break;
		case DIC_REGISTER_NO:
			printf("未注册\n");
			break;
		case DIC_WORD_FAND:
			printf("找到单次信息\n");
			break;
		case DIC_WORD_ING:
			printf("正在查询单词\n");
			break;
		case DIC_WORD_NOFAND:
			printf("未找到单词\n");
			break;
		case DIC_HISTORY_HAVE:
			printf("找到历史\n");
			break;
		case DIC_HISTORY_ING:
			printf("正在查询历史\n");
			break;
		case DIC_HISTORY_NULL:
			printf("无历史\n");
			break;
		case DIC_SERVER_CLOSE:
			printf("服务器已关闭\n");
			break;
		case DIC_BUF_FULL:
			printf("缓存已满\n");
			break;
		case DIC_ERROR:
			printf("未知错误\n");
			break;
		default:
			printf("目前为止加载成功\n");
			break;
	}
}
int login_start(int fd){
	lr tts;
	tts.head=DIC_LOGIN_ING;//登录开头为登录枚举值
	return input_info_lr(fd,&tts);
}
int register_start(int fd){
	lr tts;
	tts.head=DIC_REGISTER_ING;//注册开头为注册枚举
	return input_info_lr(fd,&tts);
}
int input_info_lr(int fd,lr *p){
	int8_t buf;
	printf("请输入您要登录或者注册的账户名:\n");
	scanf("%[^\n]",(char*)p->name);//需要强转成字符串类型
	while(getchar()!='\n');
	printf("请输入您要登录或则注册的密码:\n");
	scanf("%[^\n]",(char*)p->passwd);
	while(getchar()!='\n');
	send_account_ms(fd,p,&buf,0);
	myperror();//检测发送接受是否登录
	if(buf==DIC_LOGIN_SUCCEED){//服务器返回一个枚举的成员来判断是否成功
		printf("您已成功登录\n");
		strcpy(client_name,(char*)p->name);//更新正在登录的账户
		printf("--client:%s\n",client_name);
		return DIC_LOGIN_SUCCEED;
	}else if(buf==DIC_REGISTER_SUCCEED){
		printf("您已成功注册\n");
		return DIC_REGISTER_SUCCEED;
	}else{
		printf("您登录或注册失败，请重新选择\n");
		return DIC_LOGIN_FAILED;
	}
}
void send_account_ms(int fd,const void *p,void* buf,int a){
	int ret=-1;
	do{
		if(0==a){
			printf("%d\n",((lr*)p)->head);//查看下头信息
			ret=send(fd,(lr*)p,sizeof(lr),0);
		}else if(1==a){
			printf("%d\n",((word*)p)->head);//查看下头信息
			ret=send(fd,(word*)p,sizeof(word),0);
		}else{
			printf("%d\n",((hc*)p)->head);
			ret=send(fd,(hc*)p,sizeof(hc),0);
		}
	}while(ret<0&&EINTR==errno);
	if(ret<0&&EPIPE==errno){
		perror("set");
		printf("对方关闭了链接\n");
		myflag=DIC_SERVER_CLOSE;
		return;
	}
	if(0==ret){
		printf("发送过多导致缓冲区已满\n");
		myflag=DIC_BUF_FULL;
		return;
	}
	printf("等待服务器回应\n");
	ret=-1;
	do{
		if(0==a)
			ret=recv(fd,(int8_t*)buf,1,0);
		else if(1==a){
			bzero(buf,BUFSIZ);//将上一次查找的解析值清空
			ret=recv(fd,(int8_t*)buf,BUFSIZ,0);
		}
		else
			ret=recv(fd,(his*)buf,sizeof(his),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0){
		perror("recv");
		myflag=DIC_ERROR;
		return;
	}
	if(ret==0){
		printf("服务器关闭");
		myflag=DIC_SERVER_CLOSE;
		return;
	}
}
void search_start(int fd){
	word wd;
	wd.head=DIC_WORD_ING;
	char info_word[BUFSIZ];
	printf("请输入你要查询的单词:\n");
	scanf("%[^\n]",(char*)wd.word);
	while(getchar()!='\n');
	send_account_ms(fd,&wd,info_word,1);
	if(strncasecmp(info_word,"nofind",6)==0)
		printf("no_find\n");
	else
		printf("---%s\n",(char*)info_word);
}
void search_history(int fd){
	hc my_his;
	his fan;
	my_his.head=DIC_HISTORY_ING;
	strcpy((char*)my_his.client,client_name);
	send_account_ms(fd,&my_his,&fan,2);
	int i;
	for(i=0;i<(int)(fan.num);i++){
		printf("%s--%s\n",(fan.words[i]).word,(fan.words[i]).time);
	}
}
