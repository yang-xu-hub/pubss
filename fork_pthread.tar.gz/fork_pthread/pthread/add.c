#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define THRNUM 20
#define FNAME "/tmp/out"
#define LINESIZE 1024
static pthread_mutex_t mut=PTHREAD_MUTEX_INITIALIZER;
static void *thr_add(void *p){
	FILE *fp=NULL;
	char linebuf[LINESIZE];
	fp=fopen(FNAME,"r+");
	if(NULL==fp){
		perror("fopen");
		exit(1);
	}
	pthread_mutex_lock(&mut);
	fgets(linebuf,LINESIZE,fp);
	fseek(fp,0,SEEK_SET);
	fprintf(fp,"%d\n",atoi(linebuf)+1);
	fclose(fp);
	pthread_mutex_unlock(&mut);
	pthread_exit(NULL);
}
int main(int argc, const char *argv[])
{
	pthread_t pid[THRNUM];
	int err,i;
	for(i=0;i<THRNUM;i++){
		err=pthread_create(pid+i,NULL,thr_add,NULL);
		if(err){
			fprintf(stderr,"pthread_create err%d\n",strerror(err));
			exit(1);
		}
	}
	for(i=0;i<THRNUM;i++){
		pthread_join(pid[i],NULL);
	}
	pthread_mutex_destroy(&mut);
	return 0;
}
