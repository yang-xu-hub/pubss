#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define LEFT 10000000
#define RIGHT 10002000
#define PTHREADNUM 4
static int num=0;
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond=PTHREAD_COND_INITIALIZER;
static void *thr_func(void *p){
	int i,j,mark;
	while(1){
		mark=1;
		pthread_mutex_lock(&mutex);
		while(!num){
			pthread_cond_wait(&cond,&mutex);
		}
		if(num==-1){
			pthread_mutex_unlock(&mutex);
			break;
		}
		i=num;
		num=0;
		pthread_cond_broadcast(&cond);
		pthread_mutex_unlock(&mutex);
		for(j=2;j<i/2;j++){
			if(i%j==0){
				mark=0;
				break;
			}
		}
		if(mark){
			fprintf(stdout,"thread %d -- %d is yes\n",(int)p,i);
		}
	}
	pthread_exit(NULL);
}
int main(int argc, const char *argv[])
{
	int i,err;
    pthread_t pid[PTHREADNUM];
	for(i=0;i<PTHREADNUM;i++){
		err=pthread_create(pid+i,NULL,thr_func,(void*)i);
		if(err){
			fprintf(stderr,"pthread create error %d\n",strerror(err));
			exit(1);
		}
	}
	for(i=LEFT;i<RIGHT;i++){
		pthread_mutex_lock(&mutex);
		while(num){
			pthread_cond_wait(&cond,&mutex);
		}
		num=i;
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
	}
	pthread_mutex_lock(&mutex);
	while(num){
		pthread_cond_wait(&cond,&mutex);
	}
	num=-1;
	pthread_cond_broadcast(&cond);
	pthread_mutex_unlock(&mutex);
	for(i=0;i<PTHREADNUM;i++){
		pthread_join(pid[i],NULL);
	}
	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&cond);
	return 0;
}
