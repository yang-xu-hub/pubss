#ifndef SEM_H__
#define SEM_H__
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define LEFT 10000000
#define RIGHT 10002000
#define MAX_SEM 7
struct mysem{
	int value;
	pthread_mutex_t mutex;
	pthread_cond_t cond;
};
typedef struct mysem ms;
ms *init_sem(int);
int addsem(ms*,int);
int subsem(ms*,int);
void destroy_sem(ms**);
#endif
