#include "sem.h"
static ms *msem=NULL;
static void *thr_func(void *p){
	int i=(int)p;
	int j,mark=1;
	for(j=2;j<i/2;j++){
		if(i%j==0){
			mark=0;
			break;
		}
	}
	if(mark){
		fprintf(stdout,"-- %d is yes\n",i);
	}
	//sleep(5);
	addsem(msem,1);
	pthread_exit(NULL);
}
int main(int argc, const char *argv[])
{
	int i,err;
    pthread_t pid[RIGHT-LEFT+1];
	msem=init_sem(MAX_SEM);
	for(i=LEFT;i<=RIGHT;i++){
		subsem(msem,1);
		err=pthread_create(pid+i-LEFT,NULL,thr_func,(void*)i);
		if(err){
			fprintf(stderr,"pthread create error %d\n",strerror(err));
			exit(1);
		}
		pthread_detach(pid[i-LEFT]);
	}
	/*
	for(i=0;i<=RIGHT-LEFT;i++){
		pthread_join(pid[i],NULL);
	}*/
	destroy_sem(&msem);
	return 0;
}
