#include "sem.h"
ms *init_sem(int val){
	ms *p;
	p=(ms*)malloc(sizeof(ms));
	if(NULL==p){
		fprintf(stderr,"malloc error\n");
		exit(1);
	}
	p->value=val;
	pthread_mutex_init(&p->mutex,NULL);
	pthread_cond_init(&p->cond,NULL);
	return p;
}
int addsem(ms *p,int add){
	pthread_mutex_lock(&p->mutex);
	p->value+=add;
	if(p->value>=MAX_SEM){
		p->value=MAX_SEM;
	}
	pthread_cond_broadcast(&p->cond);
	pthread_mutex_unlock(&p->mutex);
	return add;
}
int subsem(ms *p,int sub){
	pthread_mutex_lock(&p->mutex);
	while(p->value<sub){
		pthread_cond_wait(&p->cond,&p->mutex);
	}
	p->value-=sub;
	pthread_mutex_unlock(&p->mutex);
	return sub;
}
void destroy_sem(ms **p){
	pthread_mutex_destroy(&(*p)->mutex);
	pthread_cond_destroy(&(*p)->cond);
	free(*p);
	*p=NULL;
}
