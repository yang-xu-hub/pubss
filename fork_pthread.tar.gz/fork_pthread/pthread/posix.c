#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define PTHREADSIZE 4
static pthread_mutex_t mut[PTHREADSIZE];
static int next(int i){
	if(i+1==PTHREADSIZE)
		return 0;
	return i+1;
}
static void *thr_func(void *p){
	int k=(int)p;
	int c='a'+k;
	while(1){
		pthread_mutex_lock(mut+k);
		write(1,&c,1);
		pthread_mutex_unlock(mut+next(k));
	}
	pthread_exit(NULL);
}
int main(int argc, const char *argv[])
{
	pthread_t pid[PTHREADSIZE];
	int i,err;
	for(i=0;i<PTHREADSIZE;i++){
		pthread_mutex_init(mut+i,NULL);
		pthread_mutex_lock(mut+i);
		err=pthread_create(pid+i,NULL,thr_func,(void*)i);
		if(err){
			fprintf(stderr,"pthread create err %d\n",strerror(err));
			exit(1);
		}
	}
	pthread_mutex_unlock(mut+0);
	alarm(5);
	for(i=0;i<PTHREADSIZE;i++){
		pthread_join(pid[i],NULL);
	}
	for(i=0;i<PTHREADSIZE;i++){
		pthread_mutex_destroy(mut+i);
	}
	return 0;
}
