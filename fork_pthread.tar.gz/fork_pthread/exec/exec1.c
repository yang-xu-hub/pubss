#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main(int argc, const char *argv[])
{
	pid_t pid;
	puts("begin");
	fflush(NULL);//刷新所有缓冲区
	pid=fork();
	if(pid<0){
		perror("fork");
		exit(0);
	}
	if(pid==0){
		execl("/bin/date","data","+%s",NULL);
		perror("execl");
		exit(0);
	}
	wait(NULL);
	puts("end");
	return 0;
}
