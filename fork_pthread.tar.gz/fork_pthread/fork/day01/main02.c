#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#define START 300000
#define LAST  300020
int main(int argc, const char *argv[])
{
	pid_t pid=-1;
	int i,j;
	int mark;
	for(i=START;i<=LAST;i++){
		mark=1;
		pid=fork();
		if(pid<0){
			perror("fork");
			exit(0);
		}
		if(pid==0){
			for(j=2;j<i/2;j++){
				if(i%j==0){
					mark=0;
					break;
				}
			}
			if(mark){
				printf("%d是一个质数\n",i);
			}
			exit(0);
		}
	}
	return 0;
}
