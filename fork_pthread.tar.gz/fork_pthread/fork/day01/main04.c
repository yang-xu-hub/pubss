#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <wait.h>
#include <sys/types.h>
#define START 30000000
#define LAST  30002000
#define N 4
int main(int argc, const char *argv[])
{
	pid_t pid=-1;
	int i,j,k;
	int mark;
	for(k=1;k<N;k++){ 
		pid=fork();
		if(pid<0){
			perror("fork");
			for(k=N-1-k;k<N;k++)
				wait(NULL);
			exit(0);
		}
		if(pid==0){
			printf("fork%d begin\n",k);
			for(i=START+k;i<=LAST;i+=k){
				mark=1;
				for(j=2;j<i/2;j++){
					if(i%j==0){
						mark=0;
						break;
					}
				}
				if(mark){
					printf("进程%d %d是一个质数\n",k,i);
				}
				//sleep(1);
			}
			printf("%d over\n",k);
			exit(0);
		}
	}
	for(i=1;i<N;i++){
		wait(NULL);
		printf("wait %d\n",i);
	}
	return 0;
}
