#include <stdio.h>
#include <unistd.h>
#define START 300000
#define LAST  300020
int main(int argc, const char *argv[])
{
	int i,j;
	int mark;
	for(i=START;i<=LAST;i++){
		mark=1;
		for(j=2;j<i/2;j++){
			if(i%j==0){
				mark=0;
				break;
			}
		}
		if(mark){
			printf("%d是一个质数\n",i);
		}
	}
	return 0;
}
